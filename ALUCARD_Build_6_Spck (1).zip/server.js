require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.error("NEXA: OPENAI_API_KEY is missing. Create a .env file in this project.");
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (req, res) => {
  res.json({
    ok: Boolean(process.env.OPENAI_API_KEY),
    message: process.env.OPENAI_API_KEY
      ? "NEXA image API is configured."
      : "Add OPENAI_API_KEY to .env."
  });
});

app.post("/api/image", async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || "").trim();

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: "API key is not configured. Put your new key in the .env file."
      });
    }

    if (!prompt) {
      return res.status(400).json({ error: "Enter an image prompt." });
    }

    const result = await client.images.generate({
      model: "gpt-image-2",
      prompt,
      size: "1024x1024"
    });

    const item = result?.data?.[0];

    if (!item) {
      return res.status(502).json({ error: "The image model returned no image." });
    }

    if (item.url) return res.json({ image_url: item.url });

    if (item.b64_json) {
      return res.json({
        image_url: `data:image/png;base64,${item.b64_json}`
      });
    }

    return res.status(502).json({ error: "Unsupported image response." });
  } catch (error) {
    console.error("NEXA image error:", error);
    res.status(500).json({
      error: error?.message || "Image generation failed."
    });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`NEXA Build 6 running on port ${port}`);
});
