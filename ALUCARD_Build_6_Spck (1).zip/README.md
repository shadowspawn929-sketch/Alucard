# NEXA Build 6 — Spck NodeJS

This build is specifically arranged for the Spck NodeJS terminal shown in your screenshot.

## Why Build 6 is different
Your Spck terminal does not support the normal Bash `export` command.
So this build uses the `dotenv` package and a local `.env` file instead.

## Setup in Spck

1. Extract/open this project in Spck.
2. Open the Spck terminal in the project folder.
3. Run:

npm install

4. Create a file named `.env` in the project root.
5. Put this inside it:

OPENAI_API_KEY=YOUR_NEW_KEY_HERE
PORT=3000

6. Save `.env`.
7. Run:

npm start

8. Open the local address/preview that Spck provides.

## Important
Do NOT use:
export OPENAI_API_KEY=...

This build does not need the export command.

Do NOT use the API key that was previously posted in chat. Create a new key first and put only the new key in `.env`.

The `.gitignore` excludes `.env` and node_modules if you later use version control.

## Model
The server sends image requests to GPT-Image-2.

The API key stays server-side in Node.js rather than being placed in index.html.
